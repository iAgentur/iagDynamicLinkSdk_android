package ch.iagentur.deeplinks

data class DeeplinkData(val params: Map<String, String>) {

    val url: String? get() = params["android"]
    val fallbackUrl: String? get() = params["android_fallback"]
    val desktopUrl: String? get() = params["desktop"]

    fun isResolved(): Boolean {
        return params.containsKey("android") || params.containsKey("android_fallback")
    }

    override fun toString(): String {
        return "URL: $url\nFallback: $fallbackUrl\nDesktop: $desktopUrl"
    }
}