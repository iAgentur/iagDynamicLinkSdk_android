package ch.iagentur.deeplinks

import android.net.Uri
import android.util.Base64
import java.net.URLDecoder
import java.net.URLEncoder
import org.json.JSONObject

internal class DeeplinkParser() {

    companion object {
        private val KNOWN_KEYS = listOf(
            "ios_fallback", "android_fallback", "ios", "android", "desktop", "id"
        )
    }

    fun parse(uri: Uri): DeeplinkData? {
        val decodedUrl = URLDecoder.decode(uri.toString(), Charsets.UTF_8.name())

        val queryStart = decodedUrl.indexOf('?')
        if (queryStart == -1 || queryStart == decodedUrl.length - 1) {
            return null
        }

        val query = decodedUrl.substring(queryStart + 1)
        val params = parseKnownParams(query).toMutableMap()

        // Expand payload in android URLs
        params["android"]?.let { params["android"] = expandPayload(it) }
        params["android_fallback"]?.let { params["android_fallback"] = expandPayload(it) }

        return if (params.isNotEmpty()) DeeplinkData(params) else null
    }

    private fun parseKnownParams(query: String): Map<String, String> {
        data class KeyMatch(val key: String, val keyStart: Int)

        val matches = mutableListOf<KeyMatch>()

        for (key in KNOWN_KEYS) {
            val pattern = "$key="
            var searchFrom = 0
            while (searchFrom < query.length) {
                val idx = query.indexOf(pattern, searchFrom)
                if (idx == -1) break
                if (idx == 0 || query[idx - 1] == '&') {
                    matches.add(KeyMatch(key, idx))
                    break
                }
                searchFrom = idx + 1
            }
        }

        matches.sortBy { it.keyStart }

        val result = mutableMapOf<String, String>()
        for (i in matches.indices) {
            val valueStart = matches[i].keyStart + matches[i].key.length + 1
            val valueEnd = if (i + 1 < matches.size) {
                matches[i + 1].keyStart - 1 // skip the '&' before next known key
            } else {
                query.length
            }
            if (valueStart <= valueEnd) {
                result[matches[i].key] = query.substring(valueStart, valueEnd)
            }
        }

        return result
    }

    /**
     * If the URL contains a `payload` query parameter with a Base64-encoded JSON value,
     * replaces it with the key-value pairs from the decoded JSON.
     *
     * Example:
     *   tagigaming://games?payload=eyJnYW1lIjoiZ3Vlc3NyLnB1enpsci5uZXQiLCJmcmllbmRDb2RlIjoiMTIzMjMifQ==
     * becomes:
     *   tagigaming://games?game=guessr.puzzlr.net&friendCode=12323
     */
    private fun expandPayload(url: String): String {
        val qIdx = url.indexOf('?')
        if (qIdx == -1) return url

        val base = url.substring(0, qIdx)
        val queryPart = url.substring(qIdx + 1)
        val pairs = queryPart.split("&")

        val expandedParams = mutableListOf<String>()
        for (pair in pairs) {
            val eqIdx = pair.indexOf('=')
            if (eqIdx == -1) {
                expandedParams.add(pair)
                continue
            }
            val key = pair.substring(0, eqIdx)
            val value = pair.substring(eqIdx + 1)

            if (key == "payload") {
                try {
                    val json = String(Base64.decode(value, Base64.DEFAULT))
                    val jsonObject = JSONObject(json)
                    for (jsonKey in jsonObject.keys()) {
                        val jsonValue = jsonObject.getString(jsonKey)
                        expandedParams.add("$jsonKey=${URLEncoder.encode(jsonValue, Charsets.UTF_8.name())}")
                    }
                } catch (_: Exception) {
                    expandedParams.add(pair)
                }
            } else {
                expandedParams.add(pair)
            }
        }

        return if (expandedParams.isEmpty()) base else "$base?${expandedParams.joinToString("&")}"
    }
}