package ch.iagentur.deeplinks

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.provider.Settings
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

internal class DeeplinkApiClient(
    private val host: String,
    private val apiKey: String,
    private val printLogs: Boolean
) {

    suspend fun resolve(
        context: Context,
        uri: Uri,
    ): DeeplinkData? = withContext(Dispatchers.IO) {
        val shortLink = uri.lastPathSegment ?: return@withContext null
        val userId = uri.getQueryParameter("user_id")
        val deviceId = getDeviceId(context)
        val json = JSONObject().apply {
            put("short_link", shortLink)
            put("os_version", Build.VERSION.SDK_INT)
            put("os", "android")
            put("device_type", Build.MODEL ?: "unknown")
            put("manufacturer", Build.MANUFACTURER ?: "unknown")
            put("user_id", deviceId)
            put("device_unique_id", deviceId)
        }

        val url = URL("$host/device-info")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-api-key", apiKey)
            connectTimeout = 5000
            readTimeout = 5000
        }

        if (printLogs) {
            Log.d("DeeplinkSdk", "POST $url")
            Log.d("DeeplinkSdk", "Request body: $json")
        }

        conn.outputStream.use { it.write(json.toString().toByteArray()) }

        val responseCode = conn.responseCode
        val responseBody = try {
            conn.inputStream.bufferedReader().readText()
        } catch (e: IOException) {
            conn.errorStream?.bufferedReader()?.readText() ?: ""
        }

        if (printLogs) {
            Log.d("DeeplinkSdk", "Response code: $responseCode")
            Log.d("DeeplinkSdk", "Response body: $responseBody")
        }

        return@withContext if (conn.responseCode in 200..299) {
            val jsonObj = JSONObject(responseBody)

            val resMap = mutableMapOf<String, String>().apply {
                put("android", jsonObj.optString("android_url"))
                put("android_fallback", jsonObj.optString("android_fallback_url"))
                put("desktop", jsonObj.optString("desktop_url"))
            }

            DeeplinkData(resMap)
        } else {
            null
        }
    }

    @SuppressLint("HardwareIds")
    private fun getDeviceId(context: Context): String {
        return Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID
        )
    }
}