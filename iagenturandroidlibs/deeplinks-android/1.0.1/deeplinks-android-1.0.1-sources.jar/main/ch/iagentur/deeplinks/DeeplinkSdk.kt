package ch.iagentur.deeplinks

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class DeeplinkSdk private constructor(
    private val parser: DeeplinkParser,
    private val apiClient: DeeplinkApiClient
) {

    companion object {
        @Volatile
        private var instance: DeeplinkSdk? = null

        /**
         * Initializes the DeeplinkSdk with the given host and API key.
         * This method must be called before any other DeeplinkSdk methods.
         * @param host The host URL for the Deeplink API.
         * @param apiKey The API key for accessing the Deeplink API.
         * @param printLogs If true, logs will be printed to the console.
         */
        fun init(host: String, apiKey: String, printLogs: Boolean = false) {
            synchronized(this) {
                instance = DeeplinkSdk(
                    DeeplinkParser(),
                    DeeplinkApiClient(host, apiKey, printLogs)
                )
            }
        }

        /**
         * Returns the singleton instance of DeeplinkSdk.
         * @throws IllegalStateException if the SDK has not been initialized by calling init().
         * @return The singleton instance of DeeplinkSdk.
         */
        fun getInstance(): DeeplinkSdk {
            return instance
                ?: throw IllegalStateException("DeeplinkSdk not initialized. Call init() first.")
        }
    }

    /**
     * Retrieves the dynamic link data from the provided intent.
     * Case1: Firstly tried to find "android_url" and "android_fallback_url" in the intent.data uri query params
     * Case2: Else makes API request to get dynamic link data
     * @param context The application context.
     * @param intent The intent containing the deep link URI.
     * @return A DeeplinkTask that will eventually contain the DeeplinkData or an error.
     */
    fun getDynamicLink(context: Context, intent: Intent): DeeplinkTask<DeeplinkData> {
        val task = DeeplinkTask<DeeplinkData>()
        val uri = intent.data

        if (uri == null) {
            task.complete(Result.failure(IllegalArgumentException("Intent has no data Uri")))
            return task
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val parsed = parser.parse(uri)

                if (parsed?.isResolved() == true) {
                    // Already full deep link
                    task.complete(Result.success(parsed))
                } else {
                    // Resolve via API
                    val resolved = apiClient.resolve(context, uri)
                    if (resolved != null) {
                        task.complete(Result.success(resolved))
                    } else {
                        task.complete(Result.failure(IllegalStateException("Failed to resolve link")))
                    }
                }
            } catch (e: Exception) {
                task.complete(Result.failure(e))
            }
        }
        return task
    }
}