package ch.iagentur.deeplinks

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DeeplinkTask<T> {
    private var successListener: ((T) -> Unit)? = null
    private var failureListener: ((Throwable) -> Unit)? = null

    private val mainScope = CoroutineScope(Dispatchers.Main)

    /**
     * Adds a listener that will be called if the task is successful.
     * @param listener The listener to be called.
     * @return This [DeeplinkTask] instance.
     */
    fun addOnSuccessListener(listener: (T) -> Unit): DeeplinkTask<T> {
        this.successListener = listener
        maybeDispatch()
        return this
    }

    /**
     * Adds a listener that will be called if the task fails.
     * @param listener The listener to be called.
     * @return This [DeeplinkTask] instance.
     */
    fun addOnFailureListener(listener: (Throwable) -> Unit): DeeplinkTask<T> {
        this.failureListener = listener
        maybeDispatch()
        return this
    }

    private var result: Result<T>? = null

    internal fun complete(result: Result<T>) {
        this.result = result
        maybeDispatch()
    }

    private fun maybeDispatch() {
        val result = this.result ?: return

        mainScope.launch {
            result.fold(
                onSuccess = { successListener?.invoke(it) },
                onFailure = { failureListener?.invoke(it) }
            )
        }
    }
}